<?php
//File: protected/config/main.php
// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

require( dirname(__FILE__).'/../../config.php' );

return array(

    'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
    
    'name'=>( is_array( @$conf['site'] ) ? $conf['site']['name'] : 'FusionCMS v0.1-DEV' ),
    
    'defaultController'=>'core',
 
    // preloading 'log' component
    'preload'=>array('log'),
 
    // autoloading model and component classes
    'import'=>array(
        'application.models.*',
        'application.components.*',
        'application.controllers.CoreController',
    ),
    
    // application components
    'components'=>array(
        'errorHandler'=>array(
            'errorAction'=>'//core/error',
        ),
        
        'user'=>array(
            // enable cookie-based authentication
            'allowAutoLogin'=>true,
            // force 401 HTTP error if authentication needed
            'loginUrl'=>null,
        ),
        
        'db'=>array(
            'class'=>'CDbConnection',
            'emulatePrepare'=>true,
            'connectionString'=>'mysql:host='.( isset( $conf['db']['hostname'] ) ? $conf['db']['hostname'] : 'localhost' ).';dbname='.( isset( $conf['db']['database'] ) ? $conf['db']['database'] : '' ),
            'username'=>( isset( $conf['db']['username'] ) ? $conf['db']['username'] : 'root' ),
            'password'=>( isset( $conf['db']['password'] ) ? $conf['db']['password'] : '' ),
        ),

        'settings'=>array(
            'class'             => 'CmsSettings',
            'cacheComponentId'  => 'cache',
            'cacheId'           => 'global_website_settings',
            'cacheTime'         => 84000,
            'tableName'         => 'settings',
            'dbComponentId'     => 'db',
            'createTable'       => true,
            'dbEngine'          => 'InnoDB',
        ),

        'urlManager'=>array(
            'urlFormat' => 'path',
            'showScriptName' => false,
            'caseSensitive' => false,
            'rules'=>array(
            ),
        ),
        
        'cache'=>array(
            'class'=>'system.caching.CDbCache',
        ),
    ),
    
);