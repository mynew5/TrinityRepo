<?php

class CoreController extends CController
{
    
    // Inital Runtime.
    public function init()
    {
        if( !file_exists( Yii::app()->basePath . '/../config.php' ) )
        {
            $this->redirect( Yii::app()->baseUrl . '/core/install' );
        }
        
        if( !defined( 'INSTALLED' ) )
        {
            $error = array( 'code'=>'500', 
                            'heading'=>'Configuration Error',
                            'message'=>'<b>Your configuration file seems to be mis-configured.
                                            You may have to re-install by clicking: 
                                            <a href="'.Yii::app()->baseUrl.'/core/install">Installation</a>!</b>'
            );
                                                
            $this->render( 'error', array( 'error'=>$error ) );
        }
        
        if( Yii::app()->request->requestUri == Yii::app()->baseUrl . '/' )
        {
            $this->render( '//portal/index' );
        }
    }
    
    // Use CoreController::initSettings()
    // to fetch Settings, return is an array.
    public function initSettings()
    {
        $settings = Yii::app()->settings->get( 'system' );
        return array(
                    array( 'sitename'=>$settings['sitename'],
                           'sitedesc'=>$settings['sitedesc'],
                           'metatags'=>$settings['metatags'],
                           'metadesc'=>$settings['metadesc'],
                    ),
        );
    }
    
    // Do nothing for actionIndex(); 
    // this is here, to stop erroring.
    public function actionIndex() {}
    
    
    // Core Error Handler:: Needs Improvements.
    public function actionError()
    {
        if( $error = Yii::app()->errorHandler->error )
        {
            $this->render( 'error', array( 'error' => $error ) );
        }
        else
        {
            $error = array( 'code'=>'404',
                            'heading'=>'Page Not Found',
                            'message'=>'<b>The page you requested was not found.<br />
                                        Request: '.Yii::app()->request->requestUri.'</b>');
                                        
            $this->render( 'error', array( 'error'=>$error ) );
        }
    }
    
}