<?php

class PortalController extends CoreController
{
    public function actionIndex()
    {
        $this->render( 'index' );
    }
}