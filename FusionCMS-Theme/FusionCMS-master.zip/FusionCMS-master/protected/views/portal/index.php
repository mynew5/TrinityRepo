<?php

    // Testing CoreController::initSettings()
    
print_r( CoreController::initSettings() );

?>