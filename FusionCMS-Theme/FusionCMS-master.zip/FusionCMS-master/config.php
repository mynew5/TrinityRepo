<?php

$conf['site']['name']   = 'FusionCMS v0.1-DEV';

$conf['db']['hostname'] = 'localhost';
$conf['db']['username'] = 'root';
$conf['db']['password'] = '';
$conf['db']['database'] = 'development';
$conf['db']['dbprefix'] = 'fcms_';

define( 'INSTALLED', ( ( is_array( $conf['site'] ) && is_array( $conf['db'] ) ? TRUE : FALSE ) );

?>