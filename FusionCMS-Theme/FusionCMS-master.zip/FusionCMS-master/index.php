<?php

/**
 *  @name   FusionCMS
 *  @vers   0.1-DEVEL
 * 
 *  @author Nick Daniels
 */

require_once(dirname(__FILE__).'/system/yii.php');

Yii::createWebApplication( dirname(__FILE__) . '/protected/config/main.php' )->run();
